<?php 
$insert = false;
$update = false;
$delete = false;
include('partials/config.php'); 


?>



<?php include_once('partials/header.php')?>
<?php include_once('partials/model.php')?>
<?php include_once('partials/nav.php')?>
   
    <!-- form start here -->

    <?php

    if(isset($_GET['delete'])){
        $sno = $_GET['delete'];
        $delete = true;
        $sql = " DELETE FROM `note` WHERE `srn` = $sno ";
        
        $reslut = mysqli_query($conn, $sql);
      

      
    }
  
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['snoEdit'])) {
            $title = $_POST['titleEdit'];
            $desc = $_POST['descEdit'];
            $sno = $_POST['snoEdit'];
    
            // Prepare the UPDATE statement
            if ($stmt = $conn->prepare("UPDATE `note` SET `title` = ?, `description` = ? WHERE `srn` = ?")) {
                // Bind parameters
                $stmt->bind_param("ssi", $title, $desc, $sno);
    
                // Execute the statement
                if ($stmt->execute()) {
                    $update = true;
                } else {
                    echo "We could not update the records due to this error --->" . $conn->error;
                }
    
                // Close the statement
                $stmt->close();
            } else {
                echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
            }
        }

        else {
            $title = $_POST['title'];
            $desc = $_POST['desc'];
    
            // Prepare the INSERT statement
            if ($stmt = $conn->prepare("INSERT INTO `note` (`title`, `description`) VALUES (?, ?)")) {
                // Bind parameters
                $stmt->bind_param("ss", $title, $desc);
    
                // Execute the statement
                $stmt->execute();
    
                // Check if insert was successful
                if ($stmt->affected_rows > 0) {
                    $insert = true;
                }
    }
}}
    

    ?>
    
    <?php
    if($insert){
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success !</strong> Your note has been inserted successfully.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    if($update){
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success !</strong> Your note has been updated successfully.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    if($delete){
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Deleted !</strong> Your note has been deleted successfully.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    ?>

    <div class="container my-4">
        <h1>Add a Note</h1>
        <form action="../note/index.php" method="post">
            <div class="mb-3">
                <label for="title" class="form-label">Note Title</label>
                <input type="text" name="title" class="form-control" id="title" aria-describedby="emailHelp">
                <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
            </div>
            <div class="mb-3">
            <label for="desc" class="form-label">Notes Description</label>
            <textarea class="form-control" name="desc" id="desc" rows="3"></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary">Add Note</button>
        </form>
    </div>


    <!-- form end here -->

    <!-- table start here -->
    <div class="container">
       <table class="table display" id="myTable">
  <thead>
    <tr>
      <th scope="col">S.NO</th>
      <th scope="col">Title</th>
      <th scope="col">Description</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>

    

  <?php
    
    $sql1 = "SELECT * FROM `note`";
    $result = mysqli_query($conn, $sql1);
    $sno = 0;
    while ($row = mysqli_fetch_assoc($result)){
        $sno = $sno + 1;
        echo "<tr>
        <th scope='row'>". $sno . "</th>
        <td> ".$row ['title'] . "</td>
        <td> ".$row ['description']. "</td> 
        <td> <button class='btn btn-sm btn-success edit' id=".$row ['srn'] .">Edit</button> <button class='delete  btn btn-sm btn-danger' id=d".$row ['srn'] ." >Delete</button> </td>  
        
      </tr>";
      
      
        
    }
    
    ?>

    
  
  </tbody>
</table>

<?php include_once('partials/footer.php')?>