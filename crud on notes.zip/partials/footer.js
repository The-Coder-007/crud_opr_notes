// Initialization for ES Users
import { Input, initMDB } from "mdb-ui-kit";

initMDB({ Input });