<?php

$server = "localhost";
$user   = "root";
$password = "";
$db_name = "notes";

$conn = mysqli_connect($server, $user, $password, $db_name);

if(!$conn){
    die ("connection error due to ----> " .mysqli_connect_error());
}
else{
    // echo "succesfully connected";
}

// creating database

// $sql = "CREATE DATABASE notes";
// $result = mysqli_query($conn, $sql);

// if($result){
//     echo "database created succesful";
// }else{
//     echo "database not created due to this error --->". mysqli_error($conn);
// }

// creating table

// $sql = "CREATE TABLE `note` (`srn` INT(11)  NOT NULL AUTO_INCREMENT, `title` VARCHAR(50) NOT NULL, `description` TEXT NOT NULL, PRIMARY KEY (`srn`))";
// $result = mysqli_query($conn, $sql);

// if($result){
//     echo "table created succesful";
// }else{
//     echo "table not created due to this error --->".mysqli_error($conn);
// }

?>