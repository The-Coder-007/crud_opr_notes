</div>
    <!-- table end here -->

<!-- Footer -->
<footer class="bg-body-tertiary bg-dark text-light text-center">
  <!-- Grid container -->
  <div class="container p-4 mt-4">
    

    <!-- Section: Form -->
    <section class="">
      <form action="">
        <!--Grid row-->
        <div class="row d-flex justify-content-center">
          <!--Grid column-->
          <div class="col-auto">
            <p class="pt-2">
              <strong>Sign up for our newsletter</strong>
            </p>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-md-5 col-12">
            <!-- Email input -->
            <div data-mdb-input-init class="form-outline mb-4">
              <input type="email" id="form5Example24" class="form-control" />
              <label class="form-label" for="form5Example24">Email address</label>
            </div>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-auto">
            <!-- Submit button -->
            <button data-mdb-ripple-init type="submit" class="btn btn-outline bg-light mb-4">
              Subscribe
            </button>
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </form>
    </section>
    <!-- Section: Form -->

    <!-- Section: Text -->
    <section class="mb-4">
      <p>
       Here we can update our term and condition throughout the several changes in out iNotes ! Thank You !
      </p>
    </section>
    <!-- Section: Text -->

    <!-- Section: Links -->
   
    <!-- Section: Links -->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2020 Copyright:
    <a class="text-reset fw-bold" href="https://mdbootstrap.com/">iNotes</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
  src="https://code.jquery.com/jquery-3.7.0.slim.min.js" integrity="sha256-tG5mcZUtJsZvyKAxYLVXrmjKBVLd6VpVccqz/r4ypFE=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>

        <script src="partials/footer.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous" ></script>

        <script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script>
           $(document).ready( function () {
             $('#myTable').DataTable();
             } );
        </script>
        <script>
            edits = document.getElementsByClassName('edit');
            Array.from(edits).forEach((element)=> {
                element.addEventListener("click", (e) =>{
                    console.log("edit", );
                    tr = e.target.parentNode.parentNode;
                    title = tr.getElementsByTagName("td")[0].innerText;
                    description = tr.getElementsByTagName("td")[1].innerText;
                    console.log(title, description);
                    titleEdit.value = title;
                    descEdit.value=description;
                    snoEdit.value = e.target.id;
                    console.log(e.target.id);
                    $('#editModal').modal('toggle');
                })
            })

            deletes = document.getElementsByClassName('delete');
                Array.from(deletes).forEach((element)=> {
                    element.addEventListener("click", (e) =>{
                        console.log("delete", );
                        sno = e.target.id.substr(1,);
                        
                        
                        if(confirm("Are you sure want to delete this note ?")){
                            console.log("yes");
                            window.location = `index.php?delete=${sno}`;
                        }else{
                            console.log("no");
                        }
                    })
                })
        </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
</body>

</html>